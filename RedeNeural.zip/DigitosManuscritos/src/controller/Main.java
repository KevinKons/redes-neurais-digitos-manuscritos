package controller;

public class Main {

    public static void main(String[] args) {
        ControllerRedeNeural controllerRedeNeural = new ControllerRedeNeural();
        controllerRedeNeural.montarEstruturaCrossValidation(5);
    }
}
